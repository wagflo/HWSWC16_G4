/**
 * @brief Provides some constants.
 */

#ifndef DEFS_H
#define DEFS_H

enum {MAX_NUM_OBJECTS = 16};
enum {FRAME_HEIGHT    = 480};
enum {FRAME_WIDTH     = 800};

#endif
